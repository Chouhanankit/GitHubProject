import React from 'react'

const About = () => {
  return (
    <>
      <div className='bg-[#141C2F] h-[100vh] text-2xl text-gray-500 p-5'>
        <div>About</div>
        <h1>Version 18.6</h1>
        <p className='text-xs'>This is Only information of GitHub Account</p>
      </div>
    </>
  )
}

export default About